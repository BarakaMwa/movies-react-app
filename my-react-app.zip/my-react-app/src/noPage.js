import React from 'react';
/*
* Renders Nothing in Case of wrong Route*/
function NoPage() {
    return (<>

    </>)
}

export default NoPage;
