$(document).ready(function () {

    $(".like-unlike").on("click", function () {
        this.hide();
    })

})